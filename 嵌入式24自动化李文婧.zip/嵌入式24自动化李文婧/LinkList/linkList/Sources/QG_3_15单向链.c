#include <stdio.h>
#include <stdlib.h>

// ���������ڵ�ṹ
typedef struct Node
{
    int data;
    struct Node* next;
} Node;

// �����½ڵ�
Node* createNode(int data)
{
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// ������ͷ������ڵ�
void insertAtHead(Node** head, int data)
{
    Node* newNode = createNode(data);
    newNode->next = *head;
    *head = newNode;
}

// ������β������ڵ�
void insertAtTail(Node** head, int data)
{
    Node* newNode = createNode(data);
    if (*head == NULL) 
    {
        *head = newNode;
        return;
    }
    Node* temp = *head;
    while (temp->next != NULL) 
    {
        temp = temp->next;
    }
    temp->next = newNode;
}

// ɾ������ͷ���ڵ�
void deleteAtHead(Node** head)
{
    if (*head == NULL) return;
    Node* temp = *head;
    *head = (*head)->next;
    free(temp);
}

// ɾ������β���ڵ�
void deleteAtTail(Node** head) 
{
    if (*head == NULL) return;
    if ((*head)->next == NULL) 
    {
        free(*head);
        *head = NULL;
        return;
    }
    Node* temp = *head;
    while (temp->next->next != NULL)
    {
        temp = temp->next;
    }
    free(temp->next);
    temp->next = NULL;
}

// ���ҽڵ�
Node* search(Node* head, int data) 
{
    Node* temp = head;
    while (temp != NULL)
    {
        if (temp->data == data)
        {
            return temp;
        }
        temp = temp->next;
    }
    return NULL;
}

// ��������
void traverse(Node* head) 
{
    Node* temp = head;
    while (temp != NULL) 
    {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

// ��ȡ��������
int getLength(Node* head)
{
    int length = 0;
    Node* temp = head;
    while (temp != NULL) 
    {
        length++;
        temp = temp->next;
    }
    return length;
}

// �ж������Ƿ�Ϊ��
int isEmpty(Node* head) 
{
    return head == NULL;
}

// �������
void clearList(Node** head) 
{
    Node* temp;
    while (*head != NULL)
    {
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }
}

int main() 
{
    Node* head = NULL;

    insertAtHead(&head, 10);
    insertAtTail(&head, 20);
    insertAtTail(&head, 30);

    traverse(head); // ���: 10 -> 20 -> 30 -> NULL

    deleteAtHead(&head);
    traverse(head); // ���: 20 -> 30 -> NULL

    deleteAtTail(&head);
    traverse(head); // ���: 20 -> NULL

    clearList(&head);
    traverse(head); // ���: NULL

    return 0;
}